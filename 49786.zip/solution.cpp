#include <iostream>
#include <fstream>
#include <vector>
#include <cstdint>

struct interval {
    int lo;
    int hi;
};

int cmp(struct interval x, interval y) {
    return x.lo < y.lo;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        std::cout << "Usage: ./solution <path/to/input_file>" << std::endl;
        return 1;
    }
    std::ifstream input(argv[1]);
    if (input.fail() || input.bad()) {
        std::cerr << "Error: input file " << argv[1] << " may not exist" << std::endl;
        return 1;
    }
    int n;
    input >> n;
    std::vector<struct interval> intervals(n + 2);
    for (int i = 1; i <= n; i++) {
        input >> intervals[i].lo >> intervals[i].hi;
    }
    input.close();
    std::sort(intervals.begin() + 1, intervals.end() - 1, cmp);
    int ans = 0;
    int bound = 0;
    for (int i = 1; i <= n; i++) {
        if (intervals[i].hi > bound) {
            ans += intervals[i].hi - std::max(bound, intervals[i].lo);
            bound = intervals[i].hi;
        }
    }
    bound = 0;
    intervals[n + 1].lo = intervals[n].hi;
    int minimumUnitsOfTime = INT32_MAX;
    for (int i = 1; i <= n; i++) {
        if (intervals[i].hi <= bound) {
            minimumUnitsOfTime = 0;
        } else {
            minimumUnitsOfTime = std::min(minimumUnitsOfTime,
                                          std::min(intervals[i + 1].lo, intervals[i].hi) -
                                          std::max(intervals[i].lo, bound));
            bound = std::max(bound, intervals[i].hi);
        }
    }
    if (minimumUnitsOfTime < 0) minimumUnitsOfTime = 0;
    std::string inputFile(argv[1]);
    std::string outputFile = inputFile.substr(0, inputFile.find_last_of('.'));
    outputFile += ".out";
    std::ofstream output(outputFile);
    output << ans - minimumUnitsOfTime << std::endl;
    output.close();
    return 0;
}
